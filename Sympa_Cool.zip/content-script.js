// Hark! L'instrument de notre vigilance est chargé et prêt!
console.log("Content script loaded and running.");

// Par cette sorcellerie, j'ordonne un temps de latence avant de relancer nos sorts, pour ne pas surcharger nos énergies magiques.
function debounce(func, wait) {
  let timeout;
  return function(...args) {
    const context = this; // Ecoute bien, noble script, car ici je retiens le contexte de notre appel.
    clearTimeout(timeout); // Arrête la minuterie, pour éviter le chaos d'appels redondants.
    timeout = setTimeout(() => func.apply(context, args), wait); // Et la relance, après un délai, par le pouvoir de notre détermination!
  };
}

// Voici comment nous révélons les erreurs cachées et apposons notre marque noire devant elles!
function displayCorrection(sentenceElement, text, corrections) {
  if (!Array.isArray(corrections)) { // Vérifie si la liste des erreurs est bien une liste, par tous les dieux du code!
    console.error('Expected corrections to be an array, received:', corrections);
    return;
  }

  console.log('Corrections:', corrections);
  corrections.sort((a, b) => a.offset - b.offset); // Tri par magie pour traiter les erreurs dans l'ordre.

  corrections.forEach(correction => {
    const { offset, length } = correction;
    console.log('Processing error at offset:', offset, 'with length:', length);

    let currentLength = 0;
    let done = false;

    // Cette invocation parcourt chaque fibre de notre texte, cherchant le lieu exact pour notre intervention.
    function processNode(node) {
      if (done) return; // Si notre tâche est accomplie, retirons-nous!
      if (node.nodeType === Node.TEXT_NODE) { // Uniquement dans les nœuds textuels, là où les mots résident.
        const nodeLength = node.textContent.length;
        if (currentLength + nodeLength > offset && !done) {
          const positionInNode = offset - currentLength; // Calculons l'endroit précis.
          const range = document.createRange(); // Par le pouvoir du Range, nous ciblons notre correction!
          range.setStart(node, positionInNode);
          range.setEnd(node, positionInNode);

          const dotSpan = document.createElement('span'); // Créons notre marque noire, un simple point!
          dotSpan.textContent = '.';
          dotSpan.style.color = 'black'; // Noir comme la nuit pour souligner l'erreur!
          range.insertNode(dotSpan); // Et l'insérons dans le tissu du texte!

          done = true; // Marquez bien, notre œuvre est accomplie ici.
          return;
        }
        currentLength += nodeLength; // Avançons dans notre quête textuelle.
      } else if (node.hasChildNodes()) {
        Array.from(node.childNodes).forEach(processNode); // Descendons plus profondément dans la hiérarchie du DOM, par les racines du document!
      }
    }

    processNode(sentenceElement); // Commencez notre quête à partir de l'élément donné.
    if (!done) {
      console.log('Error: Position for error not found in text nodes.'); // Un échec! L'erreur se cache encore.
    }
  });
}

// Voici comment nous scrutons le texte pour les erreurs, par les yeux de l'API LanguageTool.
function checkAndDisplayCorrections(sentenceElement) {
  const text = sentenceElement.innerText; // Nous prenons le texte à examiner.
  fetch(`https://api.languagetool.org/v2/check?language=fr&text=${encodeURIComponent(text)}`, {
    method: 'POST' // Par une missive POST, nous interrogeons l'oracle LanguageTool.
  })
  .then(response => response.json()) // Transformons la réponse en paroles compréhensibles (JSON).
  .then(data => {
    console.log('API Response:', data); // Affichons la réponse pour notre propre compréhension.
    if (data.matches && Array.isArray(data.matches) && data.matches.length > 0) {
      displayCorrection(sentenceElement, text, data.matches); // Si des erreurs sont trouvées, corrigeons-les.
    } else {
      console.log('No errors found or API response issue'); // Sinon, tout va bien, ou l'oracle est muet.
    }
  })
  .catch(error => {
    console.error('Error:', error); // Que les cieux nous préservent des erreurs de communication!
  });
}

// Un débouncer pour ne pas hâter nos appels à l'API.
const debouncedCheckAndDisplayCorrections = debounce(checkAndDisplayCorrections, 500);

// Une vigilance constante sur notre royaume de texte, par les yeux de l'Observateur de Mutations.
function initMutationObserver() {
  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          if (node.classList.contains('sentence')) { // Pour chaque nouvelle sentence, nous répondons!
            debouncedCheckAndDisplayCorrections(node);
          }
          node.querySelectorAll('.sentence').forEach(sentenceElement => {
            debouncedCheckAndDisplayCorrections(sentenceElement); // Et pour chaque sentence existante également!
          });
        }
      });
    });
  });

  observer.observe(document.body, { childList: true, subtree: true }); // Que notre vigilance s'étende à tout le corps du document!
}

initMutationObserver(); // Et ainsi, notre garde commence!
