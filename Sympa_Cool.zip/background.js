// Écoutez, ô valeureux navigateurs des internets! Lorsque vous apposez votre clic sur l'icône sacrée de notre extension,
// cette formule ancienne sera invoquée pour exécuter un sortilège puissant.
browser.browserAction.onClicked.addListener(function(tab) {
    // Par le pouvoir conféré par le tab actuel, o vile fenêtre du savoir, nous invoquons un script de nos arcanes,
    // un manuscrit nommé "content-script.js". Ce script est chargé de tâches nobles et ardues, déployé pour corriger et éclairer.
    browser.tabs.executeScript(tab.id, {file: "content-script.js"});
});
